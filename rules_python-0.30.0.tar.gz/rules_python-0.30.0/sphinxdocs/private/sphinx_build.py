import os
import pathlib
import sys

from sphinx.cmd.build import main

if __name__ == "__main__":
    sys.exit(main())
