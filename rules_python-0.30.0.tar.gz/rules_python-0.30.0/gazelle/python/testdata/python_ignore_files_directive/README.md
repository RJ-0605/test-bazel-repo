# python_ignore_files directive

This test case asserts that no targets are generated for ignored files.
