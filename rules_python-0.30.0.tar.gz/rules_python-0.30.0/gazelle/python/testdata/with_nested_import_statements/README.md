# With nested import statements

This test case asserts that a `py_library` is generated with dependencies
extracted from nested import statements from the Python source file.
