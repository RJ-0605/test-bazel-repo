# Simple library

This test case asserts that a simple `py_library` is generated as expected.
