# Naming convention py_binary fail

This test case asserts that a py_binary is not generated due to a naming conflict
with existing target.
