# Naming convention py_library fail

This test case asserts that a py_library is not generated due to a naming conflict
with existing target.
