# Simple test with conftest.py

This test case asserts that a simple `py_test` is generated as expected when a
`conftest.py` is present.
