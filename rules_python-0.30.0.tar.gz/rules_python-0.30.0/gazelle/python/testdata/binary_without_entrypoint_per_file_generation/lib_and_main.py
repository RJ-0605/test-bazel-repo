def library_func():
    print("library_func")


if __name__ == "__main__":
    library_func()
