# Per-file generation

This test case generates one `py_library` per file.

`__init__.py` is left empty so no target is generated for it.
