# Naming convention py_test fail

This test case asserts that a py_test is not generated due to a naming conflict
with existing target.
