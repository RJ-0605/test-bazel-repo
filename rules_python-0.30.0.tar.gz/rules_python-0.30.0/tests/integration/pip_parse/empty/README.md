# empty

A test that ensures that an empty requirements.txt does not break.
